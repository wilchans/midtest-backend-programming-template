const { env, port } = require('./core/config');
const logger = require('./core/logger')('app');
const server = require('./core/server');

const app = server.listen(port, (err) => {
  if (err) {
    logger.fatal(err, 'Failed to start the server.');
    process.exit(1);
  } else {
    logger.info(`Server runs at port ${port} in ${env} environment`);
  }
});

process.on('uncaughtException', (err) => {
  logger.fatal(err, 'Uncaught exception.');

  // Shutdown the server gracefully
  app.close(() => process.exit(1));

  // If a graceful shutdown is not achieved after 1 second,
  // shut down the process completely
  setTimeout(() => process.abort(), 1000).unref();
  process.exit(1);
});

const express = require('express');
const app = express();

const users = [
  {id: 1, name: 'John Doe'},
  {id: 2, name: 'Jane Smith'},
  {id: 3, name: 'Alice Johnson'},
  {id: 4, name: 'Bob brown'},
];

app.get('/users', (req, res) => {
  const page = parseInt(req.query.page_number) || 1:
  const pageSize = parseInt(req.query.page_size) || 10;

  const startIndex = (page-1) * pageSize;
  const endIndex = page * pageSize;

  const paginatedUsers = users.slice(startIndex, endIndex);

  res.json(paginatedUsers);
});

const PORT = process.env.Port || 3000;
app.listen(PORT, () => {
  console.log('Server started on port ${PORT');
});


const express = require('express');
const app = express();

const loginAttemps = {}

const maxLoginAttempts = 3;

app.post('/login', (req, res) => {
  const { username, password} = req.body;

  const attempts = loginAttempts[username] || 0;

  if(attempts >= maxLoginAttemts) {
    return res.status(403).json({ message: 'Anda telah mencapai batas login. Silahkan coba lagi nanti'});
  }
  app.pst('/reset-attempts', (req,) => {
    const { username } = req.body;

    delete loginAttempts[username];
    res..json({ message: 'Riwayat upaya login telat direset.'});
  });
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log('server started on port ${PORT}');
  });
}